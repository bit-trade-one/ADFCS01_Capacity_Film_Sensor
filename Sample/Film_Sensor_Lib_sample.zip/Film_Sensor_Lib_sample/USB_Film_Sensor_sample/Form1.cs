﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

using Microsoft.Win32.SafeHandles;
using USB_Film_Sensor_Library;

namespace USB_Film_Sensor_sample
{
    public partial class Form1 : Form
    {

        SafeFileHandle handle_usb_device = null;    // USB DEVICEハンドル
        byte now_threshold = 0;
        byte now_sensitivity = 0;
        const decimal THRESHOLD_MULTIPLIER = 100;

        public Form1()
        {
            InitializeComponent();
        }

        private void btn_usb_connect_Click(object sender, EventArgs e)
        {
            try
            {
                // USB DEVICEオープン
                if (handle_usb_device == null)
                {
                    handle_usb_device = USBFilmSensor.openUSB(this.Handle);
                    if (handle_usb_device != null)
                    {
                        btn_usb_connect.Enabled = false;
                        btn_usb_disconnect.Enabled = true;
                    }
                }
            }
            catch
            {
            }
        }

        private void btn_usb_disconnect_Click(object sender, EventArgs e)
        {
            int i_ret = 0;
            try
            {
                if (handle_usb_device != null)
                {
                    // USB DEVICEクローズ
                    i_ret = USBFilmSensor.closeUSB(handle_usb_device);
                    handle_usb_device = null;
                }
                btn_usb_connect.Enabled = true;
                btn_usb_disconnect.Enabled = false;
            }
            catch
            {
            }
        }

        private void btn_set_threshold_Click(object sender, EventArgs e)
        {
            try
            {
                nud_threshold.Value = (decimal)((int)now_threshold * (int)THRESHOLD_MULTIPLIER);
            }
            catch
            {
            }
        }

        private void btn_set_sensitivity_Click(object sender, EventArgs e)
        {
            try
            {
                nud_sensitivity.Value = (decimal)((int)now_sensitivity);
            }
            catch
            {
            }
        }

        private void btn_Set_Click(object sender, EventArgs e)
        {
            int i_ret = 0;
            int int_temp = 0;
            byte set_threshold = 0;
            byte set_sensitivity = 0;
            try
            {
                if (handle_usb_device != null)
                {
                    int_temp = (int)nud_threshold.Value;
                    set_threshold = (byte)((int_temp / (int)THRESHOLD_MULTIPLIER) & 0xFF);
                    int_temp = (int)nud_sensitivity.Value;
                    set_sensitivity = (byte)(int_temp & 0xFF);

                    i_ret = USBFilmSensor.set_SettingValue(handle_usb_device, set_threshold, set_sensitivity);
                    if (i_ret == 0)
                    {
                    }
                }
            }
            catch
            {
            }
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            int i_ret = 0;
            try
            {
                if (handle_usb_device != null)
                {
                    // USB DEVICEクローズ
                    i_ret = USBFilmSensor.closeUSB(handle_usb_device);
                }
            }
            catch
            {
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            int i_ret = 0;
            try
            {
                if (handle_usb_device != null)
                {
                    groupBox1.Enabled = true;
                    groupBox2.Enabled = true;

                    // USB DEVICEクローズ
                    uint sensor_value = 0;
                    byte threshold = 0;
                    byte sensitivity = 0;
                    i_ret = USBFilmSensor.get_SensorValue(handle_usb_device, ref sensor_value, ref threshold, ref sensitivity);
                    if (i_ret == 0)
                    {
                        lbl_SensorValue.Text = sensor_value.ToString();
                        txtbx_threshold.Text = string.Format("{0}", threshold * THRESHOLD_MULTIPLIER);
                        txtbx_sensitivity.Text = sensitivity.ToString();
                        now_threshold = threshold;
                        now_sensitivity = sensitivity;
                    }
                }
                else
                {
                    groupBox1.Enabled = false;
                    groupBox2.Enabled = false;
                }
            }
            catch
            {
            }
        }
    }
}
