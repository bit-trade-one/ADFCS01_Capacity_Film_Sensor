﻿namespace USB_Film_Sensor_sample
{
    partial class Form1
    {
        /// <summary>
        /// 必要なデザイナ変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージ リソースが破棄される場合 true、破棄されない場合は false です。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows フォーム デザイナで生成されたコード

        /// <summary>
        /// デザイナ サポートに必要なメソッドです。このメソッドの内容を
        /// コード エディタで変更しないでください。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lbl_SensorValue = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btn_set_sensitivity = new System.Windows.Forms.Button();
            this.btn_set_threshold = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.nud_threshold = new System.Windows.Forms.NumericUpDown();
            this.txtbx_sensitivity = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.nud_sensitivity = new System.Windows.Forms.NumericUpDown();
            this.label2 = new System.Windows.Forms.Label();
            this.txtbx_threshold = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.btn_Set = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.btn_usb_connect = new System.Windows.Forms.Button();
            this.btn_usb_disconnect = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_threshold)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_sensitivity)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lbl_SensorValue);
            this.groupBox1.Location = new System.Drawing.Point(23, 23);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(354, 67);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "センサ値";
            // 
            // lbl_SensorValue
            // 
            this.lbl_SensorValue.Font = new System.Drawing.Font("MS UI Gothic", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lbl_SensorValue.Location = new System.Drawing.Point(69, 25);
            this.lbl_SensorValue.Name = "lbl_SensorValue";
            this.lbl_SensorValue.Size = new System.Drawing.Size(217, 23);
            this.lbl_SensorValue.TabIndex = 2;
            this.lbl_SensorValue.Text = "値";
            this.lbl_SensorValue.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btn_set_sensitivity);
            this.groupBox2.Controls.Add(this.btn_set_threshold);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.nud_threshold);
            this.groupBox2.Controls.Add(this.txtbx_sensitivity);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.nud_sensitivity);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.txtbx_threshold);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.btn_Set);
            this.groupBox2.Location = new System.Drawing.Point(23, 113);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(354, 100);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "設定";
            // 
            // btn_set_sensitivity
            // 
            this.btn_set_sensitivity.Location = new System.Drawing.Point(149, 59);
            this.btn_set_sensitivity.Name = "btn_set_sensitivity";
            this.btn_set_sensitivity.Size = new System.Drawing.Size(35, 23);
            this.btn_set_sensitivity.TabIndex = 199;
            this.btn_set_sensitivity.Text = "→";
            this.btn_set_sensitivity.UseVisualStyleBackColor = true;
            this.btn_set_sensitivity.Click += new System.EventHandler(this.btn_set_sensitivity_Click);
            // 
            // btn_set_threshold
            // 
            this.btn_set_threshold.Location = new System.Drawing.Point(149, 33);
            this.btn_set_threshold.Name = "btn_set_threshold";
            this.btn_set_threshold.Size = new System.Drawing.Size(35, 23);
            this.btn_set_threshold.TabIndex = 195;
            this.btn_set_threshold.Text = "→";
            this.btn_set_threshold.UseVisualStyleBackColor = true;
            this.btn_set_threshold.Click += new System.EventHandler(this.btn_set_threshold_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(197, 17);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(41, 12);
            this.label5.TabIndex = 192;
            this.label5.Text = "設定値";
            // 
            // nud_threshold
            // 
            this.nud_threshold.Increment = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.nud_threshold.Location = new System.Drawing.Point(188, 35);
            this.nud_threshold.Maximum = new decimal(new int[] {
            25500,
            0,
            0,
            0});
            this.nud_threshold.Minimum = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.nud_threshold.Name = "nud_threshold";
            this.nud_threshold.Size = new System.Drawing.Size(55, 19);
            this.nud_threshold.TabIndex = 196;
            this.nud_threshold.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.nud_threshold.Value = new decimal(new int[] {
            100,
            0,
            0,
            0});
            // 
            // txtbx_sensitivity
            // 
            this.txtbx_sensitivity.Location = new System.Drawing.Point(92, 62);
            this.txtbx_sensitivity.Name = "txtbx_sensitivity";
            this.txtbx_sensitivity.ReadOnly = true;
            this.txtbx_sensitivity.Size = new System.Drawing.Size(55, 19);
            this.txtbx_sensitivity.TabIndex = 198;
            this.txtbx_sensitivity.TabStop = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(100, 17);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(41, 12);
            this.label4.TabIndex = 191;
            this.label4.Text = "現在値";
            // 
            // nud_sensitivity
            // 
            this.nud_sensitivity.Location = new System.Drawing.Point(188, 62);
            this.nud_sensitivity.Maximum = new decimal(new int[] {
            3,
            0,
            0,
            0});
            this.nud_sensitivity.Name = "nud_sensitivity";
            this.nud_sensitivity.Size = new System.Drawing.Size(55, 19);
            this.nud_sensitivity.TabIndex = 200;
            this.nud_sensitivity.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(20, 38);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(45, 12);
            this.label2.TabIndex = 193;
            this.label2.Text = "しきい値";
            // 
            // txtbx_threshold
            // 
            this.txtbx_threshold.Location = new System.Drawing.Point(92, 35);
            this.txtbx_threshold.Name = "txtbx_threshold";
            this.txtbx_threshold.ReadOnly = true;
            this.txtbx_threshold.Size = new System.Drawing.Size(55, 19);
            this.txtbx_threshold.TabIndex = 194;
            this.txtbx_threshold.TabStop = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(20, 66);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(29, 12);
            this.label3.TabIndex = 197;
            this.label3.Text = "感度";
            // 
            // btn_Set
            // 
            this.btn_Set.Location = new System.Drawing.Point(261, 46);
            this.btn_Set.Name = "btn_Set";
            this.btn_Set.Size = new System.Drawing.Size(75, 23);
            this.btn_Set.TabIndex = 201;
            this.btn_Set.Text = "設定";
            this.btn_Set.UseVisualStyleBackColor = true;
            this.btn_Set.Click += new System.EventHandler(this.btn_Set_Click);
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 10;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // btn_usb_connect
            // 
            this.btn_usb_connect.Location = new System.Drawing.Point(96, 225);
            this.btn_usb_connect.Name = "btn_usb_connect";
            this.btn_usb_connect.Size = new System.Drawing.Size(75, 23);
            this.btn_usb_connect.TabIndex = 2;
            this.btn_usb_connect.Text = "USB接続";
            this.btn_usb_connect.UseVisualStyleBackColor = true;
            this.btn_usb_connect.Click += new System.EventHandler(this.btn_usb_connect_Click);
            // 
            // btn_usb_disconnect
            // 
            this.btn_usb_disconnect.Enabled = false;
            this.btn_usb_disconnect.Location = new System.Drawing.Point(222, 225);
            this.btn_usb_disconnect.Name = "btn_usb_disconnect";
            this.btn_usb_disconnect.Size = new System.Drawing.Size(75, 23);
            this.btn_usb_disconnect.TabIndex = 3;
            this.btn_usb_disconnect.Text = "USB切断";
            this.btn_usb_disconnect.UseVisualStyleBackColor = true;
            this.btn_usb_disconnect.Click += new System.EventHandler(this.btn_usb_disconnect_Click);
            // 
            // Form1
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(398, 260);
            this.Controls.Add(this.btn_usb_disconnect);
            this.Controls.Add(this.btn_usb_connect);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "Form1";
            this.Text = "USBフィルム近接センサ　ライブラリサンプル";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.groupBox1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_threshold)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_sensitivity)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label lbl_SensorValue;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btn_set_sensitivity;
        private System.Windows.Forms.Button btn_set_threshold;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.NumericUpDown nud_threshold;
        private System.Windows.Forms.TextBox txtbx_sensitivity;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.NumericUpDown nud_sensitivity;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtbx_threshold;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btn_Set;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Button btn_usb_connect;
        private System.Windows.Forms.Button btn_usb_disconnect;

    }
}

